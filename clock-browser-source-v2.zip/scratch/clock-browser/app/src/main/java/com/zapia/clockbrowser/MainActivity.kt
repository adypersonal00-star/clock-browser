package com.zapia.clockbrowser

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tab
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

private val Night = Color(0xFF080B10)
private val Case = Color(0xFF343B45)
private val Face = Color(0xFF10161E)
private val Accent = Color(0xFF72E7FF)
private val Letter = Color(0xFFF4F7FB)
private val Dim = Color(0xFF9CA9B8)

private data class BrowserTab(val id: String, var url: String, var title: String, var loading: Boolean = false)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { ClockBrowserApp() } }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun ClockBrowserApp() {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var query by remember { mutableStateOf("") }
    var tabs by remember { mutableStateOf(listOf(BrowserTab(UUID.randomUUID().toString(), "", "Pestaña nueva"))) }
    var activeId by remember { mutableStateOf(tabs.first().id) }
    var showTabs by remember { mutableStateOf(false) }
    var showKeyboard by remember { mutableStateOf(false) }
    var keyboardMode by remember { mutableStateOf("browser") }
    var systemKeyboard by remember { mutableStateOf(false) }
    var voiceQuery by remember { mutableStateOf("") }
    var activeWeb by remember { mutableStateOf<WebView?>(null) }
    var focusedWebField by remember { mutableStateOf(false) }
    var webTapCount by remember { mutableIntStateOf(0) }
    var focusedNative by remember { mutableStateOf(false) }
    val active = tabs.firstOrNull { it.id == activeId } ?: tabs.first()

    val speech = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) { voiceQuery = spoken; query = spoken; navigateSearch(spoken) { url, title -> tabs = tabs.map { if (it.id == activeId) it.copy(url = url, title = title) else it } }
        }
    }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }

    MaterialTheme(colorScheme = darkColorScheme(primary = Accent, background = Night, surface = Face, onSurface = Letter)) {
        Column(Modifier.fillMaxSize().background(Night), horizontalAlignment = Alignment.CenterHorizontally) {
            WatchStrap(Modifier.fillMaxWidth().weight(0.55f))
            BoxWithConstraints(Modifier.fillMaxWidth().weight(6.6f).background(Night), contentAlignment = Alignment.Center) {
                val diameter = maxWidth.coerceAtMost(maxHeight)
                Box(Modifier.size(diameter).background(Case, CircleShape).border(2.dp, Color(0xFF66717E), CircleShape).padding(9.dp), contentAlignment = Alignment.Center) {
                    Box(Modifier.fillMaxSize().clip(CircleShape).background(Face)) {
                        // The web document occupies the center of the dial; controls follow its circular rim.
                        Column(Modifier.fillMaxSize().padding(horizontal = diameter * .105f, vertical = diameter * .105f), horizontalAlignment = Alignment.CenterHorizontally) {
                            ClockHeader(now, active.title)
                            Spacer(Modifier.height(4.dp))
                            Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White)) {
                                if (active.url.isBlank()) StartPage(now, onExample = { query = it; navigateSearch(it) { u,t -> tabs = tabs.map { old -> if (old.id == activeId) old.copy(url=u,title=t) else old } } })
                                else {
                                    val tabId = active.id
                                    AndroidView(
                                        modifier = Modifier.fillMaxSize(),
                                        factory = { ctx ->
                                            WebView(ctx).apply {
                                                activeWeb = this
                                                settings.javaScriptEnabled = true
                                                settings.domStorageEnabled = true
                                                settings.loadsImagesAutomatically = true
                                                settings.mediaPlaybackRequiresUserGesture = true
                                                webChromeClient = object : WebChromeClient() {
                                                    override fun onReceivedTitle(view: WebView?, title: String?) {
                                                        if (!title.isNullOrBlank()) tabs = tabs.map { if (it.id == tabId) it.copy(title = title.take(80)) else it }
                                                    }
                                                }
                                                webViewClient = object : WebViewClient() {
                                                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false
                                                    override fun onPageFinished(view: WebView?, url: String?) {
                                                        super.onPageFinished(view, url)
                                                        if (url != null) tabs = tabs.map { if (it.id == tabId) it.copy(url = url, loading = false) else it }
                                                        view?.evaluateJavascript("(function(){if(window.__clockBrowserKeyboard)return;window.__clockBrowserKeyboard=true;document.addEventListener('focusin',function(e){var t=e.target;if(t&&(t.tagName==='INPUT'||t.tagName==='TEXTAREA'||t.isContentEditable)){window.KlockBridge.fieldFocused();}},true);})();", null)
                                                    }
                                                }
                                                setOnTouchListener { v, event ->
                                                    if (event.action == MotionEvent.ACTION_UP) {
                                                        evaluateJavascript("(function(x,y){var e=document.elementFromPoint(x,y);return !!(e&&(e.tagName==='INPUT'||e.tagName==='TEXTAREA'||e.isContentEditable));})(${event.x},${event.y})") { r ->
                                                            if (r == "true") {
                                                                if (webTapCount == 0) {
                                                                    webTapCount = 1; focusedWebField = true; showKeyboard = true; systemKeyboard = false; keyboardMode = "web"
                                                                } else {
                                                                    systemKeyboard = true; showKeyboard = false
                                                                    post { (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(this, InputMethodManager.SHOW_IMPLICIT) }
                                                                }
                                                            } else { webTapCount = 0; focusedWebField = false }
                                                            }
                                                        }
                                                    }
                                                    false
                                                }
                                                loadUrl(active.url)
                                            }
                                        },
                                        update = { web ->
                                            activeWeb = web
                                            if (web.url != active.url && active.url.isNotBlank()) web.loadUrl(active.url)
                                        },
                                        onRelease = { web -> web.stopLoading(); web.destroy(); if (activeWeb === web) activeWeb = null }
                                    )
                                }
                            }
                            Spacer(Modifier.height(5.dp))
                            SearchStrip(
                                text = query,
                                voice = voiceQuery,
                                systemKeyboard = systemKeyboard,
                                onText = { query = it },
                                onSearch = { text -> navigateSearch(text) { u,t -> tabs = tabs.map { if (it.id == activeId) it.copy(url=u,title=t) else it }; showKeyboard = false; focusedNative = false } },
                                onVoice = { val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_WEB_SEARCH); putExtra(RecognizerIntent.EXTRA_PROMPT, "Di una dirección web o qué quieres buscar") }; runCatching { speech.launch(i) } },
                                onKey = { if (!focusedNative) { focusedNative = true; keyboardMode = "address"; showKeyboard = true } else { systemKeyboard = true; showKeyboard = false } }
                            )
                        }
                        RimButton(Modifier.align(Alignment.TopCenter).padding(top = 14.dp), "INICIO") { showTabs = false; showKeyboard = false; tabs = tabs.map { if (it.id == activeId) it.copy(url = "", title = "Clock Browser") else it } }
                        RimButton(Modifier.align(Alignment.CenterStart).padding(start = 5.dp), "ATRÁS") {
                            if (showTabs) showTabs = false else if (activeWeb?.canGoBack() == true) activeWeb?.goBack() else { showKeyboard = false; focusedWebField = false }
                        }
                        RimButton(Modifier.align(Alignment.CenterEnd).padding(end = 5.dp), "PESTAÑAS ${tabs.size}") { showKeyboard = false; showTabs = true }
                        RimButton(Modifier.align(Alignment.BottomCenter).padding(bottom = 13.dp), "NUEVA +") {
                            val t = BrowserTab(UUID.randomUUID().toString(), "", "Pestaña nueva")
                            tabs = tabs + t; activeId = t.id; query = ""; showTabs = false
                        }
                        if (showTabs) {
                            Box(Modifier.fillMaxSize().background(Color(0xF010151D)), contentAlignment = Alignment.Center) {
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Box(Modifier.fillMaxSize().clickable { showTabs = false })
                                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Column(Modifier.fillMaxSize().padding(horizontal = diameter * .19f, vertical = diameter * .17f), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("PESTAÑAS ABIERTAS", color = Accent, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                        Icon(Icons.Default.Close, contentDescription = "Close tab grid", tint = Letter, modifier = Modifier.size(23.dp).clickable { showTabs = false })
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        itemsIndexed(tabs, key = { _, tab -> tab.id }) { _, tab ->
                                            Column(Modifier.fillMaxWidth().aspectRatio(.86f).clip(RoundedCornerShape(12.dp)).background(if (tab.id == activeId) Color(0xFF1B3642) else Color(0xFF1C242D)).clickable {
                                                activeId = tab.id; query = tab.url; showTabs = false; showKeyboard = false
                                            }.padding(7.dp)) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text(tab.title.ifBlank { "Pestaña nueva" }, color = Letter, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                                                    Text("×", color = Accent, fontSize = 14.sp, modifier = Modifier.clickable {
                                                        val rest = tabs.filterNot { it.id == tab.id }
                                                        tabs = if (rest.isEmpty()) listOf(BrowserTab(UUID.randomUUID().toString(), "", "Pestaña nueva")) else rest
                                                        if (activeId == tab.id) activeId = tabs.first().id
                                                    })
                                                }
                                                Spacer(Modifier.height(5.dp))
                                                Text(tab.url.ifBlank { "Inicio de Clock Browser" }, color = Dim, fontSize = 7.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
                                            }
                                        }
                                    }
                                    Text("Toca una pestaña para abrirla · toca el centro para cerrar", color = Dim, fontSize = 8.sp, modifier = Modifier.padding(top = 4.dp))
                                }
                                }
                            }
                        }
                    }
                }
            }
            WatchStrap(Modifier.fillMaxWidth().weight(0.55f))
        }
        if (showKeyboard && !systemKeyboard) {
            ClockKeyboard(
                mode = keyboardMode,
                onCharacter = { ch ->
                    if (keyboardMode == "address") query += ch
                    else activeWeb?.evaluateJavascript("(function(ch){var e=document.activeElement;if(!e)return;var s=e.selectionStart??e.value?.length??0;var en=e.selectionEnd??s;if(e.isContentEditable){document.execCommand('insertText',false,ch);}else{var v=e.value??'';e.value=v.slice(0,s)+ch+v.slice(en);e.setSelectionRange(s+ch.length,s+ch.length);e.dispatchEvent(new Event('input',{bubbles:true}));e.dispatchEvent(new Event('change',{bubbles:true}));}})(${org.json.JSONObject.quote(ch)})", null)
                },
                onDelete = { if (keyboardMode == "address") query = query.dropLast(1) else activeWeb?.evaluateJavascript("(function(){var e=document.activeElement;if(!e)return;if(e.isContentEditable){document.execCommand('delete');}else if(e.value!=null){var s=e.selectionStart||e.value.length;var en=e.selectionEnd||s;if(s===en&&s>0)s--;e.value=e.value.slice(0,s)+e.value.slice(en);e.setSelectionRange(s,s);e.dispatchEvent(new Event('input',{bubbles:true}));}})()", null) },
                onEnter = { if (keyboardMode == "address") { navigateSearch(query) { u,t -> tabs = tabs.map { if (it.id == activeId) it.copy(url=u,title=t) else it } }; showKeyboard = false } else { activeWeb?.evaluateJavascript("(function(){var e=document.activeElement;if(e)e.dispatchEvent(new KeyboardEvent('keydown',{key:'Enter',bubbles:true}));})()", null) } },
                onSystem = {
                    systemKeyboard = true
                    if (keyboardMode == "web") activeWeb?.let { (context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(it, InputMethodManager.SHOW_IMPLICIT) }
                },
                onClose = { showKeyboard = false; systemKeyboard = false }
            )
        }
    }
}

@Composable private fun WatchStrap(modifier: Modifier) {
    Row(modifier, horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.fillMaxWidth(.42f).fillMaxHeight(.82f).clip(RoundedCornerShape(20.dp)).background(Color(0xFF343C47)), contentAlignment = Alignment.Center) {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp), horizontalAlignment = Alignment.CenterHorizontally) { repeat(3) { Box(Modifier.size(6.dp).background(Color(0xFF090C11), CircleShape)) } }
        }
    }
}

@Composable private fun ClockHeader(now: Date, title: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), color = Letter, fontSize = 28.sp, fontWeight = FontWeight.Light)
        Text(SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(now) + "  ·  " + title.take(22), color = Accent, fontSize = 8.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable private fun StartPage(now: Date, onExample: (String) -> Unit) {
    Column(Modifier.fillMaxSize().background(Color(0xFF111820)), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("NAVEGADOR RELOJ", color = Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(now), color = Letter, fontSize = 30.sp, fontWeight = FontWeight.Light)
        Text(SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(now), color = Dim, fontSize = 9.sp)
        Spacer(Modifier.height(12.dp))
        Text("Busca en Internet o escribe una dirección abajo", color = Dim, fontSize = 8.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(horizontal = 16.dp))
        Spacer(Modifier.height(6.dp))
        Text("https://ejemplo.com", color = Accent, fontSize = 8.sp, modifier = Modifier.clickable { onExample("https://ejemplo.com") })
    }
}

@Composable private fun SearchStrip(text: String, voice: String, systemKeyboard: Boolean, onText: (String) -> Unit, onSearch: (String) -> Unit, onVoice: () -> Unit, onKey: () -> Unit) {
    Row(Modifier.fillMaxWidth().height(38.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(50)).background(Color(0xFF26323D)).border(1.dp, Accent.copy(alpha = .45f), RoundedCornerShape(50)).clickable { onKey() }.padding(horizontal = 9.dp), contentAlignment = Alignment.CenterStart) {
            if (text.isBlank()) Text("Buscar o escribir dirección", color = Dim, fontSize = 8.sp, maxLines = 1)
            BasicTextField(value = text, onValueChange = onText, singleLine = true, readOnly = !systemKeyboard, textStyle = TextStyle(color = Letter, fontSize = 9.sp), modifier = Modifier.fillMaxWidth())
        }
        RoundControl(Icons.Default.Search, "Buscar", onClick = { onSearch(text) })
        RoundControl(Icons.Default.Mic, "Búsqueda por voz", onClick = onVoice)
    }
}

@Composable private fun RoundControl(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0xFF22313B)).border(1.dp, Accent.copy(alpha = .4f), CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(icon, contentDescription = label, tint = Accent, modifier = Modifier.size(15.dp))
    }
}

@Composable private fun RimButton(modifier: Modifier, text: String, onClick: () -> Unit) {
    Box(modifier.height(25.dp).clip(CircleShape).background(Color(0xFF25313A)).border(1.dp, Accent.copy(alpha = .38f), CircleShape).clickable { onClick() }.padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
        Text(text, color = Letter, fontSize = 7.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable private fun ClockKeyboard(mode: String, onCharacter: (String) -> Unit, onDelete: () -> Unit, onEnter: () -> Unit, onSystem: () -> Unit, onClose: () -> Unit) {
    var symbols by remember { mutableStateOf(false) }
    var upper by remember { mutableStateOf(false) }
    val letters = if (symbols) listOf("!@#$%^&*", "()_+-=[]", "{};:'\"/?.") else listOf("1234567890", "qwertyuiop", "asdfghjkl", "zxcvbnm")
    Box(Modifier.fillMaxSize().background(Color(0xB5000000)), contentAlignment = Alignment.Center) {
        Column(Modifier.fillMaxWidth(.94f).aspectRatio(1f).clip(CircleShape).background(Color(0xFF111A23)).border(2.dp, Accent, CircleShape).padding(26.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(if (mode == "web") "TECLADO DEL RELOJ" else "TECLADO DEL RELOJ", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            letters.forEach { row -> Row(horizontalArrangement = Arrangement.Center) { row.forEach { ch ->
                val k = if (upper) ch.uppercaseChar().toString() else ch.toString()
                KeyboardKey(k) { onCharacter(k); if (!symbols) upper = false }
            } } }
            Row(horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                KeyboardKey(if (upper) "⇧✓" else "⇧") { upper = !upper }
                KeyboardKey("ESPACIO") { onCharacter(" ") }
                KeyboardKey("⌫") { onDelete() }
                KeyboardKey("↵") { onEnter() }
            }
            Row(horizontalArrangement = Arrangement.Center) {
                KeyboardKey("SÍM") { symbols = !symbols }
                KeyboardKey("ABC") { symbols = false }
                KeyboardKey("123") { symbols = true }
            }
            Row(horizontalArrangement = Arrangement.Center) {
                KeyboardKey("TECLADO MÓVIL") { onSystem() }
                KeyboardKey("LISTO") { onClose() }
            }
            Text("Toca TECLADO MÓVIL para usar el teclado del teléfono", color = Dim, fontSize = 7.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable private fun KeyboardKey(label: String, onClick: () -> Unit) {
    Box(Modifier.padding(2.dp).height(25.dp).defaultMinSize(minWidth = 24.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFF293744)).clickable { onClick() }.padding(horizontal = 5.dp), contentAlignment = Alignment.Center) {
        Text(label, color = Letter, fontSize = if (label.length > 2) 7.sp else 10.sp, fontWeight = FontWeight.Medium)
    }
}

private fun navigateSearch(input: String, onNavigate: (String, String) -> Unit) {
    val raw = input.trim()
    if (raw.isBlank()) return
    val url = when {
        raw.startsWith("http://", true) || raw.startsWith("https://", true) -> raw
        raw.contains('.') && !raw.contains(' ') -> "https://$raw"
        else -> "https://www.google.com/search?q=" + UriEncode(raw)
    }
    onNavigate(url, raw.take(40))
}
private fun UriEncode(s: String): String = java.net.URLEncoder.encode(s, "UTF-8")
